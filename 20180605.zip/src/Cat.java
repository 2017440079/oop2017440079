
public class Cat extends Animal {
	Cat(String name) {
		super(name);
	}
	@Override
	void sing() {
		System.out.println(this.name + " �߿�");
	}
}
