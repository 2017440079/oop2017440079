import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class CalculatorStructure extends JFrame {

	JButton[] buttons = new JButton[10];
	JButton plusButton = new JButton("+");
	JButton canButton = new JButton("C");
	JButton calButton = new JButton("=");
	JTextField tf;
	int i,reset=1,plus=0;
	int former=0,latter=0,tmp=0;
	
	public CalculatorStructure() {
		
		setTitle("Calculator");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		
		Toolkit kit = Toolkit.getDefaultToolkit();
		Dimension screenSize = kit.getScreenSize();
		setSize(300,400);
		setLocation(screenSize.width/2, screenSize.height/2);
		
		JPanel disPanel = new JPanel();
		JPanel butPanel = new JPanel();
		tf = new JTextField(25);
		tf.setHorizontalAlignment(JTextField.RIGHT);
		tf.setText("0");
		
		for(i=0;i<10;i++)
		{
			buttons[i] = new JButton(Integer.toString(i));
			buttons[i].addActionListener(new ML());
		}
		plusButton.addActionListener(new ML());
		canButton.addActionListener(new ML());
		calButton.addActionListener(new ML());
		tf.addActionListener(new ML());
		
		disPanel.setLayout(new FlowLayout());
		butPanel.setLayout(new GridLayout(0,3,5,5));
		
		butPanel.add(canButton);
		butPanel.add(plusButton);
		butPanel.add(calButton);
		for(i=0;i<10;i++)
			butPanel.add(buttons[i]);
		disPanel.add(tf);
		this.add(butPanel,BorderLayout.CENTER);
		this.add(disPanel,BorderLayout.NORTH);
		this.setVisible(true);
		
	}
		private class ML implements ActionListener
		{
				@Override
				public void actionPerformed(ActionEvent e) {
					String s = e.getActionCommand();
					if(s.equals("C")) //�� �ʱ�ȭ
					{
						reset = 1;
						plus = 0;
						tf.setText("0");
						former = 0;
						latter = 0;
						tmp = 0;
					}
					for(i=0;i<10;i++) //�ؽ�Ʈ�ʵ忡 ���� �Է��Ͽ� ����
					{		
						String c = String.valueOf(i);
						if(reset==1 && plus==0)
						{
							if(s.equals(c) && tf.getText()!="0")
							{
								tf.setText(c);
								reset = 0;
								former = Integer.valueOf(tf.getText());
							}
							if(s.equals(c) && tf.getText()=="0")
							{
								tf.setText("0");
								reset = 0;
								former = Integer.valueOf(tf.getText());
							}
						}
						else if(reset==0 && plus==0)
						{
							if(s.equals(c))
							{
								tf.setText(tf.getText()+c);
								former = Integer.valueOf(tf.getText());
							}
						}
					}
					if(s.equals("+")) //���� �ν�
					{
						plus++;
						reset = 1;
						latter = latter + tmp;
					}
					for(i=0;i<10;i++) // ���� ����
					{		
						String c = String.valueOf(i);
						if(reset==1 && plus==1)
						{
							if(s.equals(c) && tf.getText()!="0")
							{
								tf.setText(c);
								reset = 0;
								latter = Integer.valueOf(tf.getText());
							}
							if(s.equals(c) && tf.getText()=="0")
							{
								tf.setText("0");
								reset = 0;
								latter = Integer.valueOf(tf.getText());
							}
						}
						else if(reset==0 && plus==1)
						{
							if(s.equals(c))
							{
								tf.setText(tf.getText()+c);
								latter = Integer.valueOf(tf.getText());
							}
						}
					}
					for(i=0;i<10;i++) //���� ���� ����
					{	
						String c = String.valueOf(i);
						if(reset==1 && plus>1)
						{
							if(s.equals(c) && tf.getText()!="0")
							{
								tf.setText(c);
								reset = 0;
								tmp = Integer.valueOf(tf.getText());
							}
							if(s.equals(c) && tf.getText()=="0")
							{
								tf.setText("0");
								reset = 0;
								tmp = Integer.valueOf(tf.getText());
							}
						}
						else if(reset==0 && plus>1)
						{
							if(s.equals(c))
							{
								tf.setText(tf.getText()+c);
								tmp = Integer.valueOf(tf.getText());
							}
						}
					}
					if(s.equals("=")) //���� ��� ��ȯ
					{
						tf.setText(String.valueOf(former+latter+tmp));
					}
					
			}
		}
		
		
}

