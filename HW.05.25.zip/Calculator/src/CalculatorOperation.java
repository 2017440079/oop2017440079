public class CalculatorOperation {
	public static void main(String[] args) {
		CalculatorStructure Calculator = new CalculatorStructure();
	}
}
