
public class TwentyFive {

	
	public static void symmetry(int N) {
		
		int I;
		
		for(I=1;I<(N+1)/2;I++)
			System.out.print((N+1)/2-I);
		
		System.out.print("0");
		
		for(I=1;I<(N+1)/2;I++)
			System.out.print(I);
	
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a=0;
		int i=1;
		int j;
		
		while(a!=6) {
			
			j=11-2*a;
			
			for(i=1;i<=j;i++)
				System.out.print("*");
			
			System.out.print(" ");
			
			symmetry(j);
			
			a++;
			System.out.println("");
			
		}
		
		a=1;
		
		while(a!=6) {
			
			j=2*a+1;
			
			for(i=1;i<=j;i++) 
				System.out.print("*");
			
			System.out.print(" ");
			
			symmetry(j);
			
			a++;
			System.out.println("");
			
		}
	}
	
}
