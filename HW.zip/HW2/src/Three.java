
public class Three {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int number = 1;
		int sum = 0;
		
		while(number<100) {
			if(number%3 == 0)
				sum = sum + number;
			number++;
		}
		
		System.out.println(sum);
	}

}
