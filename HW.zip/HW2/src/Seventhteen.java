
public class Seventhteen {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int sum=0;
		int i;
		
		for(i=1;i<=100;i++)
			sum = sum + i;
		
		System.out.println(sum);
		
	}

}
