
public class Box {
	private Object data;
	public void set(Object data) {
		this.data = data; 
	}
	public Object get() {
		return data;
	}
}
